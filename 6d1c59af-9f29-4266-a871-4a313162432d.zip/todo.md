# Aurora Architecture — Repo Setup & Push

## Setup
- [x] Init git repo
- [ ] Create `aurora-architecture` repo on GitHub via API
- [ ] Configure git identity & remote

## Architecture Docs
- [ ] Write `README.md` — top-level overview
- [ ] Write `docs/architecture.md` — full layered spec
- [ ] Write `docs/agents/` — one file per domain agent
- [ ] Write `docs/communication.md` — message bus, state, registry
- [ ] Write `docs/mapping.md` — how this maps to current reality

## Push
- [ ] Commit all docs
- [ ] Push to GitHub